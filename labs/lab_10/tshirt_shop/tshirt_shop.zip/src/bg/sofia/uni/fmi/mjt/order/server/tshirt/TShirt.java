package bg.sofia.uni.fmi.mjt.order.server.tshirt;

public record TShirt(Size size, Color color) {
}
