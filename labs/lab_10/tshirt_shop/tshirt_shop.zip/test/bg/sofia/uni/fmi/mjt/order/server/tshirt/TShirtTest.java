package bg.sofia.uni.fmi.mjt.order.server.tshirt;

public class TShirtTest {

}
