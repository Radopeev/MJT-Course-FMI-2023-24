package bg.sofia.uni.fmi.mjt.order.server.order;

public class OrderTest {
}
