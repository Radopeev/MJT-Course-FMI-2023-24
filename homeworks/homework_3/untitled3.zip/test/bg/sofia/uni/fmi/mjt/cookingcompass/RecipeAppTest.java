package bg.sofia.uni.fmi.mjt.cookingcompass;

import bg.sofia.uni.fmi.mjt.cookingcompass.exceptions.FailedRecipeSearch;
import bg.sofia.uni.fmi.mjt.cookingcompass.exceptions.RecipeAppException;
import bg.sofia.uni.fmi.mjt.cookingcompass.recipe.RecipeResponse;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;


import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class RecipeAppTest {
    private static RecipeAPI recipeAppTest;

    @BeforeAll
    static void setup() {
        recipeAppTest = new RecipeAppHTTP();
    }

    @Test
    void testSearchRecipesWhenKeywordIsNull() {
        List<String> healthLabels = List.of("vegan", "sesame-free");
        List<String> mealTypes = List.of("Breakfast", "Lunch");
        assertThrows(IllegalArgumentException.class, () -> recipeAppTest.searchRecipes(null, healthLabels, mealTypes),
            "Should throw an exception when keyword is null");
    }

    @Test
    void testSearchRecipesWhenHealthLabelsIsNull() {
        String keywords = "Chicken";
        List<String> mealTypes = List.of("Breakfast", "Lunch");
        assertThrows(IllegalArgumentException.class, () -> recipeAppTest.searchRecipes(keywords, null, mealTypes),
            "Should throw an exception when health labels is null");
    }

    @Test
    void testSearchRecipesWhenMealTypesIsNull() {
        String keywords = "Chicken";
        List<String> healthLabels = List.of("vegan", "sesame-free");
        assertThrows(IllegalArgumentException.class, () -> recipeAppTest.searchRecipes(keywords, healthLabels, null),
            "Should throw an exception when meal types is null");
    }

    @Test
    void testsearchRecipesWhenThereIsInvalidHealthLabel() {
        String keywords = "Chicken";
        List<String> healthLabels = List.of("vegan", "invalid");
        List<String> mealTypes = List.of("Breakfast", "Lunch");
        assertThrows(IllegalArgumentException.class,
            () -> recipeAppTest.searchRecipes(keywords, healthLabels, mealTypes),
            "Should throw an exception when there is an invalid health label");
    }

    @Test
    void testsearchRecipesWhenSearchFailed() {
        String keywords = "Chicken";
        List<String> healthLabels = List.of("vegan", "low-fat-abs");
        List<String> mealTypes = List.of("Breakfast", "Lunch");
        assertThrows(FailedRecipeSearch.class, () -> recipeAppTest.searchRecipes(keywords, healthLabels, mealTypes),
            "Should throw an exception when search fails");
    }

    @Test
    void testSearchRecipesWhenThereIsInvalidMealTypes() {
        String keywords = "Chicken";
        List<String> healthLabels = List.of("vegan", "sesame-free");
        List<String> mealTypes = List.of("invalid", "Lunch");
        assertThrows(IllegalArgumentException.class,
            () -> recipeAppTest.searchRecipes(keywords, healthLabels, mealTypes),
            "Should throw an exception when there is an invalid meal type");
    }

    @Test
    void testSearchRecipesWhenThereAreKeyword() throws FailedRecipeSearch, InterruptedException {
        String keyword = "chicken rice";
        List<String> healthLabels = List.of("vegan","sesame-free");
        List<String> webHealthLabels = List.of("Vegan","Sesame-Free");
        List<String> mealTypes = List.of("Breakfast","Lunch");
        List<String> webMealTypes = List.of("lunch/dinner", "breakfast","snack");
        List<RecipeResponse.Recipe> result = recipeAppTest.searchRecipes(keyword,healthLabels,mealTypes);

        assertTrue(result.stream().allMatch(recipe -> recipe.healthLabels().containsAll(webHealthLabels)),
            "All recipes must contain all health labels");
        assertTrue(result.stream().allMatch(recipe ->containsAnyMealType(recipe.mealType(), webMealTypes)),
            "All recipes must contain at least one of the meal types");
    }

    @Test
    void testSearchRecipesWhenThereAreNoKeyword() throws FailedRecipeSearch {
        String keyword = "";
        List<String> healthLabels = List.of("vegan","sesame-free");
        List<String> webHealthLabels = List.of("Vegan","Sesame-Free");
        List<String> mealTypes = List.of("Breakfast","Lunch");
        List<String> webMealTypes = List.of("lunch/dinner", "teatime","breakfast","snack");
        List<RecipeResponse.Recipe> result = recipeAppTest.searchRecipes(keyword,healthLabels,mealTypes);

        assertTrue(result.stream().allMatch(recipe -> recipe.healthLabels().containsAll(webHealthLabels)),
            "All recipes must contain all health labels");
        assertTrue(result.stream().allMatch(recipe ->containsAnyMealType(recipe.mealType(), webMealTypes)),
            "All recipes must contain at least one of the meal types");
    }


    private boolean containsAnyMealType(List<String> recipeMealTypes, List<String> webMealTypes) {
        for (String webMealType : webMealTypes) {
            if (recipeMealTypes.contains(webMealType)) {
                return true;
            }
        }
        return false;
    }
}
