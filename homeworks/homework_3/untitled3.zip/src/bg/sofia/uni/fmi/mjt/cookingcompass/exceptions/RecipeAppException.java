package bg.sofia.uni.fmi.mjt.cookingcompass.exceptions;

public class RecipeAppException extends RuntimeException {

    public RecipeAppException(String message) {
        super(message);
    }

    public RecipeAppException(String message, Throwable cause) {
        super(message, cause);
    }
}
