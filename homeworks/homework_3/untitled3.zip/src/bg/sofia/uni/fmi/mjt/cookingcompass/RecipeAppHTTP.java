package bg.sofia.uni.fmi.mjt.cookingcompass;

import bg.sofia.uni.fmi.mjt.cookingcompass.exceptions.FailedRecipeSearch;
import bg.sofia.uni.fmi.mjt.cookingcompass.exceptions.RecipeAppException;
import bg.sofia.uni.fmi.mjt.cookingcompass.recipe.HealthLabel;
import bg.sofia.uni.fmi.mjt.cookingcompass.recipe.MealType;

import bg.sofia.uni.fmi.mjt.cookingcompass.recipe.RecipeResponse;
import com.google.gson.Gson;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class RecipeAppHTTP implements RecipeAPI {
    private static final String QUERY_PARAM_KEYWORD = "q=";
    private static final String QUERY_PARAM_APP_ID = "app_id=";
    private static final String QUERY_PARAM_APP_KEY = "app_key=";
    private static final String QUERY_PARAM_HEALTH = "health=";
    private static final String QUERY_PARAM_MEAL_TYPES = "mealTypes=";
    private static final String QUERY_PARAM_FROM = "from=";
    private static final String QUERY_PARAM_TO = "to=";
    private static final String AMPERSAND = "&";
    private static final String SPACE = "%20";
    private static final String API_ENDPOINT = "https://api.edamam.com/api/recipes/v2?type=any";
    private static final String APP_ID = "48a0b944";
    private static final String APP_KEY = "252f247f5085801a533c4c922f46bd40";
    private static final int MAX_REQUESTS = 2;
    private static final int STATUS_CODE_OK = 200;
    private static final int PAGE_BEGIN = 0;
    private static final int PAGE_END = 20;
    private static final int STARTING_NUMBER_OF_REQUESTS = 0;
    private final HttpClient httpClient;
    private final Gson gson;

    public RecipeAppHTTP() {
        httpClient = HttpClient.newBuilder().build();
        gson = new Gson();
    }

    private void assertHealthLabel(String healthLabel) {
        for (HealthLabel label : HealthLabel.values()) {
            if (label.getApiParameter().equals(healthLabel)) {
                return;
            }
        }
        throw new IllegalArgumentException("There is no such health label" + healthLabel);
    }

    private void assertMealType(String mealType) {
        for (MealType type : MealType.values()) {
            if (type.getValue().equals(mealType)) {
                return;
            }
        }
        throw new IllegalArgumentException("There is no such meal type" + mealType);
    }

    private String buildUrl(String keyword, List<String> healthLabels, List<String> mealTypes, int from, int to) {
        StringBuilder uriBuilder = new StringBuilder();
        if (!keyword.isBlank()) {
            List<String> separatedKeyword = List.of(keyword.split(" "));
            uriBuilder.append(String.format("%s&%s%s&%s%s&%s%s&%s%s&%s%s", API_ENDPOINT, QUERY_PARAM_KEYWORD,
                String.join(SPACE, separatedKeyword), QUERY_PARAM_APP_ID, APP_ID, QUERY_PARAM_APP_KEY,
                APP_KEY, QUERY_PARAM_FROM, from, QUERY_PARAM_TO, to));
        } else {
            uriBuilder = new StringBuilder(String.format("%s&%s%s&%s%s",
                API_ENDPOINT, QUERY_PARAM_APP_ID, APP_ID, QUERY_PARAM_APP_KEY, APP_KEY));
        }

        if (!healthLabels.isEmpty()) {
            String heatlhLabelsParam =
                healthLabels.stream().map(label -> QUERY_PARAM_HEALTH + label).collect(Collectors.joining(AMPERSAND));
            uriBuilder.append(AMPERSAND).append(heatlhLabelsParam);
        }
        if (!mealTypes.isEmpty()) {
            String mealTypesParam =
                mealTypes.stream().map(label -> QUERY_PARAM_MEAL_TYPES + label).collect(Collectors.joining(AMPERSAND));
            uriBuilder.append(AMPERSAND).append(mealTypesParam);
        }
        return uriBuilder.toString();
    }

    private List<RecipeResponse.Recipe> requestRecipes(String url, String keyword,
                                                       List<String> healthLabels, List<String> mealTypes)
        throws URISyntaxException, IOException, InterruptedException, RecipeAppException {
        List<RecipeResponse.Recipe> allRecipes = new ArrayList<>();
        int  from;
        int to = PAGE_END;
        int count;
        int numberOfMadeRequest = STARTING_NUMBER_OF_REQUESTS;

        do {
            numberOfMadeRequest++;
            HttpRequest request = HttpRequest.newBuilder(new URI(url))
                .header("Accept", "application/json")
                .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == STATUS_CODE_OK) {
                RecipeResponse recipeResponse = gson.fromJson(response.body(), RecipeResponse.class);
                List<RecipeResponse.Recipe> recipes =
                    recipeResponse.hits().stream().map(RecipeResponse.Hit::recipe).toList();
                allRecipes.addAll(recipes);
                count = recipeResponse.count();
                from = to;
                to += recipes.size();
                url = buildUrl(keyword, healthLabels, mealTypes, from, to);
            } else {
                throw new RecipeAppException("HTTP Request Failed with Error code: " + response.statusCode());
            }
        } while (numberOfMadeRequest < MAX_REQUESTS &&  from < count);

        return allRecipes;
    }

    private void assertKeywords(String keywords) {
        if (keywords == null) {
            throw new IllegalArgumentException("Keywords cannot be null");
        }
    }

    private void assertHealthLabels(List<String> healthLabels) {
        if (healthLabels == null) {
            throw new IllegalArgumentException("Health label cannot be null");
        }

        for (String healthLabel : healthLabels) {
            assertHealthLabel(healthLabel);
        }

    }

    private void assertMealTypes(List<String> mealTypes) {
        if (mealTypes == null) {
            throw new IllegalArgumentException("Health label cannot be null");
        }

        for (String mealType : mealTypes) {
            assertMealType(mealType);
        }
    }

    @Override
    public List<RecipeResponse.Recipe> searchRecipes(String keywords, List<String> healthLabels, List<String> mealTypes)
        throws FailedRecipeSearch {
        assertKeywords(keywords);
        assertHealthLabels(healthLabels);
        assertMealTypes(mealTypes);
        try {
            String url = buildUrl(keywords, healthLabels, mealTypes, PAGE_BEGIN, PAGE_END);
            return requestRecipes(url, keywords, healthLabels, mealTypes);
        } catch (URISyntaxException e) {
            throw new RecipeAppException("Invalid URI syntax while building URL", e);
        } catch (IOException e) {
            throw new RecipeAppException("IO operation failed during recipe request", e);
        } catch (InterruptedException e) {
            throw new RecipeAppException("Thread interrupted during recipe request", e);
        } catch (RecipeAppException e) {
            throw new FailedRecipeSearch("Recipe search failed with an application-specific error", e);
        }

    }
}
