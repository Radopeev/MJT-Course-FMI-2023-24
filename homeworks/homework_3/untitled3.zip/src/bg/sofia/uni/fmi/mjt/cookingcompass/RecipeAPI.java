package bg.sofia.uni.fmi.mjt.cookingcompass;

import bg.sofia.uni.fmi.mjt.cookingcompass.exceptions.FailedRecipeSearch;
import bg.sofia.uni.fmi.mjt.cookingcompass.recipe.RecipeResponse;

import java.util.List;

public interface RecipeAPI {
    List<RecipeResponse.Recipe> searchRecipes(String keywords, List<String> healthLabels, List<String> mealTypes) throws FailedRecipeSearch;
}
